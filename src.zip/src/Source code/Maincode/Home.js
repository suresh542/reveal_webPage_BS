import React from "react";
import "./Home.scss"
// import "./ImportPart"
import Header from "../Header/Header";
import About from "./About/About";
import Services from "./Services/Services";
import Portfolio from "./PORTFOLIO/Portfolio";



export default function Home(){
    // var bgImage = document.getElementById("Home1")
    // bgImage.setAttribute("style", "background:url(../image/imageSlide1.jpg)")
    return(
        <div className="MainHomePage">
            <div className="Header">
                <Header/>
            </div>
            <section className="Home1" >
            {/* <img src="../image/imageslider2.jpg" alt="" /> */}
                <div className="Home" id="Home" data-aos="fade-up">
                    <h2>
                        Making <span>your ideas</span> <br /> happen!
                    </h2>
                   <div className="buttons mt-5">
                   <a href="about" className="btn-getStarted ">Get Started</a>
                    <a href="content" className="btn-OurProject">Our Project</a>
                   </div>
                </div>
            </section>
            <div className="mainCode">
                <section className="mt-5" data-aos="fade-up">
                    <About/>
                </section>
            </div>
            <div className="service">
                <section>
                    <Services
                    />
                </section>
            </div>
                <div className="portfolio mt-2">
                    <Portfolio/>
                </div>
        </div>
    );
}